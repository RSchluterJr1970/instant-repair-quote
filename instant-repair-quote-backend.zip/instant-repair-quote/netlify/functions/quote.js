import { parse } from 'formidable';
import { randomUUID } from 'crypto';
import { buffer } from 'node:stream/consumers';

export const config = {
  api: {
    bodyParser: false,
  },
};

const BASE_RATES = {
  'HVAC': 120,
  'Electrical': 110,
  'Plumbing': 115,
  'Appliance': 95,
  'Door/Window': 90,
  'Flooring': 85,
  'Roof/Exterior': 125,
  'IT/Low Voltage': 100,
  'Other': 100,
};

const URGENCY_MULT = {
  'ASAP / Emergency (0-4h)': 2.0,
  'Same Day (4-8h)': 1.5,
  'Next Business Day': 1.2,
  'Flexible (2-5 days)': 1.0,
};

function estimateHours(category, description='') {
  const d = (description || '').toLowerCase();
  const kw = (k) => d.includes(k);
  // simple heuristics
  if (category === 'Plumbing') {
    if (kw('clog') || kw('leak')) return 2;
    if (kw('replace') || kw('install')) return 3;
    return 2.5;
  }
  if (category === 'HVAC') {
    if (kw('no cool') || kw('no heat') || kw('compressor')) return 3;
    if (kw('maintenance') || kw('tune')) return 1.5;
    return 2.5;
  }
  if (category === 'Electrical') {
    if (kw('breaker') || kw('short') || kw('outlet')) return 2;
    if (kw('panel') || kw('rewire')) return 4;
    return 2.5;
  }
  if (category === 'Roof/Exterior') return 3.5;
  if (category === 'Flooring') return 3;
  if (category === 'Appliance') return 2;
  if (category === 'Door/Window') return 2.5;
  if (category === 'IT/Low Voltage') return 2;
  return 2.5;
}

function partsAllowance(category, description='') {
  const d = (description || '').toLowerCase();
  if (category === 'Plumbing') {
    if (d.includes('toilet') || d.includes('faucet')) return 75;
    return 50;
  }
  if (category === 'HVAC') {
    if (d.includes('compressor') || d.includes('motor')) return 250;
    return 120;
  }
  if (category === 'Electrical') {
    if (d.includes('breaker') || d.includes('panel')) return 200;
    return 80;
  }
  if (category === 'Roof/Exterior') return 180;
  if (category === 'Flooring') return 150;
  if (category === 'Appliance') return 90;
  if (category === 'Door/Window') return 120;
  if (category === 'IT/Low Voltage') return 60;
  return 100;
}

function calculateQuote({ category, urgency, description }) {
  const rate = BASE_RATES[category] ?? BASE_RATES['Other'];
  const mult = URGENCY_MULT[urgency] ?? 1.0;
  const hours = estimateHours(category, description);
  const parts = partsAllowance(category, description);
  const labor = rate * hours;
  const subtotal = Math.round((labor * mult + parts) * 100) / 100;
  const tax = Math.round((subtotal * 0.0825) * 100) / 100; // 8.25% example
  const total = Math.round((subtotal + tax) * 100) / 100;
  return { rate, hours, mult, parts, labor, subtotal, tax, total };
}

async function readMultipart(req) {
  return new Promise((resolve, reject) => {
    const form = new (parse.IncomingForm)({ multiples: true, maxFileSize: 20 * 1024 * 1024 });
    form.parse(req, (err, fields, files) => {
      if (err) return reject(err);
      resolve({ fields, files });
    });
  });
}

async function sendEmail({ to, subject, html }) {
  const key = process.env.SENDGRID_API_KEY;
  const from = process.env.FROM_EMAIL || 'no-reply@example.com';
  if (!key) return { ok: false, reason: 'SENDGRID_API_KEY not set — skipping email send.' };
  const payload = {
    personalizations: [{ to: [{ email: to }] }],
    from: { email: from, name: process.env.COMPANY_NAME || 'Instant Repair Quote' },
    subject,
    content: [{ type: 'text/html', value: html }]
  };
  const res = await fetch('https://api.sendgrid.com/v3/mail/send', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${key}`, 'Content-Type':'application/json' },
    body: JSON.stringify(payload)
  });
  return { ok: res.ok, status: res.status };
}

function emailTemplate({ company, region }, reqData, calc, quoteId) {
  const lines = `
    <div style="font-family:system-ui,Segoe UI,Roboto;max-width:640px;margin:auto">
      <h2>${company} — Quote ${quoteId}</h2>
      <p>Thanks for your request. Here is your instant estimate.</p>
      <h3>Request</h3>
      <ul>
        <li><b>Name:</b> ${reqData.fullName}</li>
        <li><b>Company:</b> ${reqData.company || '-'}</li>
        <li><b>Category:</b> ${reqData.category}</li>
        <li><b>Urgency:</b> ${reqData.urgency}</li>
        <li><b>Model:</b> ${reqData.model || '-'}</li>
        <li><b>Description:</b> ${reqData.description || '-'}</li>
        <li><b>Location:</b> ${reqData.location}, ${reqData.zipcode}</li>
      </ul>
      <h3>Estimate</h3>
      <table cellpadding="6" cellspacing="0" border="0" style="border-collapse:collapse">
        <tr><td>Base rate</td><td style="text-align:right">$${calc.rate.toFixed(2)}/hr</td></tr>
        <tr><td>Estimated hours</td><td style="text-align:right">${calc.hours.toFixed(1)} h</td></tr>
        <tr><td>Urgency multiplier</td><td style="text-align:right">× ${calc.mult.toFixed(2)}</td></tr>
        <tr><td>Parts allowance</td><td style="text-align:right">$${calc.parts.toFixed(2)}</td></tr>
        <tr><td style="border-top:1px solid #ddd">Subtotal</td><td style="text-align:right;border-top:1px solid #ddd">$${calc.subtotal.toFixed(2)}</td></tr>
        <tr><td>Tax (8.25%)</td><td style="text-align:right">$${calc.tax.toFixed(2)}</td></tr>
        <tr><td style="border-top:1px solid #ddd"><b>Total</b></td><td style="text-align:right;border-top:1px solid #ddd"><b>$${calc.total.toFixed(2)}</b></td></tr>
      </table>
      <p style="margin-top:16px">Reply to approve or request a dispatch. We’ll confirm final scope and schedule a technician.</p>
      <p style="color:#666;font-size:12px">Serving ${region}. This is an instant estimate — final invoice may vary after onsite diagnosis.</p>
    </div>
  `;
  return lines;
}

export async function handler(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  try {
    // Netlify provides a raw body buffer; we need to reconstruct a request-like stream for formidable
    const boundary = event.headers['content-type'] || event.headers['Content-Type'];
    if (!boundary || !boundary.includes('multipart/form-data')) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Expected multipart/form-data' }) };
    }

    // Build a Readable stream from the raw body
    const raw = Buffer.from(event.body, event.isBase64Encoded ? 'base64' : 'utf8');
    const req = new ReadableStream();
    // A small shim to let formidable parse the buffer
    const { Readable } = await import('node:stream');
    const s = new Readable();
    s.push(raw);
    s.push(null);
    s.headers = { 'content-type': boundary };

    const { fields } = await new Promise((resolve, reject) => {
      const form = new (parse.IncomingForm)({ multiples: true, maxFileSize: 20 * 1024 * 1024 });
      form.parse(s, (err, flds, files) => {
        if (err) return reject(err);
        resolve({ fields: flds, files });
      });
    });

    const required = ['fullName','email','phone','category','description','urgency','location','zipcode'];
    for (const r of required) {
      if (!fields[r] || String(fields[r]).trim() === '') {
        return { statusCode: 400, body: JSON.stringify({ error: `Missing required field: ${r}` }) };
      }
    }

    const reqData = {
      fullName: String(fields.fullName),
      email: String(fields.email),
      phone: String(fields.phone),
      company: String(fields.company || ''),
      category: String(fields.category),
      model: String(fields.model || ''),
      description: String(fields.description || ''),
      urgency: String(fields.urgency),
      location: String(fields.location),
      zipcode: String(fields.zipcode),
      deadline: String(fields.deadline || ''),
      budget: Number(fields.budget || 0),
      contactPref: String(fields.contactPref || ''),
      po: String(fields.po || '')
    };

    const calc = calculateQuote({ category: reqData.category, urgency: reqData.urgency, description: reqData.description });
    const quoteId = randomUUID().slice(0, 8).toUpperCase();

    const html = emailTemplate({ company: process.env.COMPANY_NAME || 'Instant Repair Quote', region: process.env.REGION || 'Houston, TX' }, reqData, calc, quoteId);

    // Try sending the email; ignore errors if key not set
    let emailResult = { ok: false };
    try {
      emailResult = await sendEmail({ to: reqData.email, subject: `Your Instant Estimate — Quote ${quoteId}`, html });
    } catch (e) {
      // continue
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        ok: true,
        quoteId,
        totals: calc,
        toEmail: reqData.email,
        emailSent: emailResult.ok || false
      })
    };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ error: 'Server error', detail: String(err) }) };
  }
}