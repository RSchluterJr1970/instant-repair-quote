
# Instant Repair Quote — MVP Backend + Updated Frontend

This package gives you a working **serverless backend (Netlify Functions)** and an **updated frontend** that posts to it.

## What’s included
- `netlify/functions/quote.js` — parses form submissions, runs pricing logic, sends email via SendGrid (optional), and returns a JSON response with a quote ID + totals.
- `netlify.toml` — config so `/api/quote` maps to `/.netlify/functions/quote`
- `package.json` — dependencies + scripts
- `public/index.html` — your form updated to post to `/api/quote`
- `.env.sample` — environment variable names you should set on Netlify

## Quick Start (Netlify)
1. **Create a new Netlify site** and connect this folder (or drag‑and‑drop in the UI).
2. **Environment variables (Site settings → Environment):**
   - `SENDGRID_API_KEY` — optional (if set, function will email the quote to the requester)
   - `FROM_EMAIL` — the sender email for SendGrid (e.g. quotes@yourdomain.com)
   - `COMPANY_NAME` — appears in the email/quote
   - `REGION` — e.g. `Houston, TX` (used in email footer)
3. **Deploy**. Netlify will serve your static site from `public/` and your function at `/.netlify/functions/quote`. The redirect makes it available at `/api/quote`.
4. Open the deployed site and submit the form. You should see a success message and (if SendGrid is configured) an email with the quote.

## Local Dev
```bash
npm i -g netlify-cli
npm i
netlify dev
```
Open http://localhost:8888

## Notes
- File uploads are **accepted but ignored** in this MVP (parsed for safety; not stored). In Phase 2, upload to S3, Cloudinary, or Netlify Large Media.
- PDF generation is **not included** here; the email contains an HTML breakdown. Phase 2 can add a PDF service.
- Pricing logic lives in one place (`calculateQuote`). Tweak the rates/multipliers/heuristics for better accuracy.
